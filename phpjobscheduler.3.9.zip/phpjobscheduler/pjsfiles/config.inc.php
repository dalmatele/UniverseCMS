<?php
// ---------------------------------------------------------
 $app_name = "phpJobScheduler";
 $phpJobScheduler_version = "3.9";
// ---------------------------------------------------------

define('DBHOST', 'localhost');// database host address - localhost is usually fine

define('DBNAME', '');// database name - must already exist
define('DBUSER', '');// database username - must already exist
define('DBPASS', '');// database password for above username

define('DEBUG', true);// set to false when done testing